export const BaseUrl =  {
    'BASE_URL':'http://18.222.168.144:3030' //ip del back
}